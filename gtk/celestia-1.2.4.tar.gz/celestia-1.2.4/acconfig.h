#undef HAVE_LIBSM

/* The directory where our data will be installed in */
#undef CONFIG_DATA_DIR

/* Are we debugging ? */
#undef DEBUG

/* Log Domain for Gnome */
#undef G_LOG_DOMAIN

/* Locale Directory for Gnome (Currently unused) */
#undef GNOMELOCALEDIR

/* The directory where the HIPPARCOS/TYCHO data resides */
#undef HIP_DATA_DIR
