/* config.h.  Generated automatically by configure.  */
/* config.h.in.  Generated automatically from configure.in by autoheader.  */

/* Define if you have the ANSI C header files.  */
/* #undef STDC_HEADERS */

/* Define if your processor stores words with the most significant
   byte first (like Motorola and SPARC, unlike Intel and VAX).  */
/* #undef WORDS_BIGENDIAN */

/* Define if the X Window System is missing or not being used.  */
/* #undef X_DISPLAY_MISSING */

#define HAVE_LIBSM 1

/* The directory where our data will be installed in */
#define CONFIG_DATA_DIR "/usr/local/share/celestia"

/* Are we debugging ? */
/* #undef DEBUG */

/* Log Domain for Gnome */
#define G_LOG_DOMAIN "Celestia"

/* Locale Directory for Gnome (Currently unused) */
#define GNOMELOCALEDIR "/usr/local/share/celestia/locale"

/* The directory where the HIPPARCOS/TYCHO data resides */
#define HIP_DATA_DIR "/usr/local/share/celestia"

/* Define if you have the <GL/gl.h> header file.  */
#define HAVE_GL_GL_H 1

/* Define if you have the <GL/glu.h> header file.  */
#define HAVE_GL_GLU_H 1

/* Define if you have the <GL/glut.h> header file.  */
#define HAVE_GL_GLUT_H 1

/* Define if you have the <X11/SM/SMlib.h> header file.  */
#define HAVE_X11_SM_SMLIB_H 1

/* Define if you have the <byteswap.h> header file.  */
#define HAVE_BYTESWAP_H 1

/* Define if you have the GL library (-lGL).  */
#define HAVE_LIBGL 1

/* Define if you have the GLU library (-lGLU).  */
#define HAVE_LIBGLU 1

/* Define if you have the MesaGL library (-lMesaGL).  */
/* #undef HAVE_LIBMESAGL */

/* Define if you have the MesaGLU library (-lMesaGLU).  */
/* #undef HAVE_LIBMESAGLU */

/* Define if you have the glut library (-lglut).  */
#define HAVE_LIBGLUT 1

/* Define if you have the gtkgl library (-lgtkgl).  */
#define HAVE_LIBGTKGL 1

/* Define if you have the jpeg library (-ljpeg).  */
#define HAVE_LIBJPEG 1

/* Define if you have the png library (-lpng).  */
#define HAVE_LIBPNG 1

/* Name of package */
#define PACKAGE "celestia"

/* Version number of package */
#define VERSION "1.2.4"

