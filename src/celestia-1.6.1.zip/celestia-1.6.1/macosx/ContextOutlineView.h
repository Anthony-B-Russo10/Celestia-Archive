/* ContextOutlineView */

#import "NSOutlineView_Extensions.h"

@interface ContextOutlineView : NSOutlineView {
}
@end
