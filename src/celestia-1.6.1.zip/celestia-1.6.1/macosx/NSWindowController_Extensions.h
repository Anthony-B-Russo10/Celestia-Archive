//
//  NSWindowController_Extensions.h
//  celestia
//
//  Created by Da Woon Jung on 10/1/08.
//  Copyright 2008 Celestia Development Team
//

#import <Cocoa/Cocoa.h>


@interface NSWindowController (CelestiaWindowController)
- (void)keyDown:(NSEvent *)theEvent;
@end
