//
//  CGLInfo.h
//  celestia
//
//  Created by Bob Ippolito on Wed Jun 26 2002.
//  2005-05 Modified substantially by Da Woon Jung
//


@interface CGLInfo : NSObject {

}
+(NSString*)info;
@end
