/*
 *  Astro_PrivateAPI.h
 *  celestia
 *
 *  Created by Bob Ippolito on Sun Jun 09 2002.
 *  Copyright (c) 2002 Chris Laurel. All rights reserved.
 *
 */

#include <celengine/astro.h>
@interface Astro(PrivateAPI)
@end
