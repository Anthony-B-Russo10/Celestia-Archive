//
//  SplashScreen.h
//  celestia
//
//  Created by Da Woon Jung on 2005-12-18.
//  Copyright 2005 Chris Laurel. All rights reserved.
//

@interface SplashImageView : NSImageView
- (BOOL)mouseDownCanMoveWindow;
@end

@interface SplashWindow : NSWindow
{
}
@end
