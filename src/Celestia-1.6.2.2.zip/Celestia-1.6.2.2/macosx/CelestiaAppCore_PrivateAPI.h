/*
 *  CelestiaAppCore_PrivateAPI.h
 *  celestia
 *
 *  Created by Bob Ippolito on Fri Jun 07 2002.
 *  Copyright (c) 2002 Chris Laurel. All rights reserved.
 *
 */

#include <celestia/celestiacore.h>
#include <celestia/url.h>
#include <celengine/cmdparser.h>
extern CelestiaCore *appCore;



