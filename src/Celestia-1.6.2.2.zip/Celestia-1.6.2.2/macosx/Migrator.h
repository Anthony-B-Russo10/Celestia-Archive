//
//  Migrator.h
//  Celestia
//
//  Created by 李林峰 on 2019/10/7.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface Migrator : NSObject

+ (void)tryToMigrate;

@end

NS_ASSUME_NONNULL_END
