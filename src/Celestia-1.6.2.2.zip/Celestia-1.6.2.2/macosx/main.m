//
//  main.m
//  celestia
//
//  Created by Bob Ippolito on Fri May 17 2002.
//  Copyright (c) 2002 Chris Laurel. All rights reserved.
//

int main(int argc, const char *argv[])
{
    return NSApplicationMain(argc,argv);
}
