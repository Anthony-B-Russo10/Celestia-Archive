// orbit.cpp
//
// Copyright (C) 2001, Chris Laurel <claurel@shatters.net>
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.

#include <cmath>
#include "mathlib.h"
#include "orbit.h"


EllipticalOrbit::EllipticalOrbit(double _semiMajorAxis,
                                 double _eccentricity,
                                 double _inclination,
                                 double _ascendingNode,
                                 double _argOfPeriapsis,
                                 double _trueAnomaly,
                                 double _period,
                                 double _epoch) :
    semiMajorAxis(_semiMajorAxis),
    eccentricity(_eccentricity),
    inclination(_inclination),
    ascendingNode(_ascendingNode),
    argOfPeriapsis(_argOfPeriapsis),
    trueAnomaly(_trueAnomaly),
    period(_period),
    epoch(_epoch)
{
}

// Return the offset from the barycenter
Point3d EllipticalOrbit::positionAtTime(double t) const
{
    t = t - epoch;
    double meanMotion = 2.0 * PI / period;
    double meanAnomaly = trueAnomaly + t * meanMotion - argOfPeriapsis;

    // TODO: calculate the *real* eccentric anomaly.  This is a reasonable
    // approximation only for nearly circular orbits
    double eccAnomaly = meanAnomaly;

    double x = semiMajorAxis * cos(eccAnomaly - eccentricity);
    double z = semiMajorAxis * sqrt(1 - square(eccentricity)) * sin(eccAnomaly);

    Mat3d R = (Mat3d::yrotation(ascendingNode) *
               Mat3d::xrotation(inclination) *
               Mat3d::yrotation(argOfPeriapsis));

    return Point3d(x, 0, z) * R;
}


double EllipticalOrbit::getPeriod() const
{
    return period;
}
