// simulation.cpp
// 
// Copyright (C) 2001, Chris Laurel <claurel@shatters.net>
//
// The core of Celestia--tracks an observer moving through a
// stars and their solar systems.
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.

#include <algorithm>

#include "mathlib.h"
#include "vecmath.h"
#include "perlin.h"
#include "astro.h"
#include "simulation.h"

using namespace std;

#define VELOCITY_CHANGE_TIME      1.0f


Simulation::Simulation() :
    realTime(0.0),
    simTime(0.0),
    timeScale(1.0),
    typedText(""),
    stardb(NULL),
    starNameDB(NULL),
    solarSystemCatalog(NULL),
    visibleStars(NULL),
    closestSolarSystem(NULL),
    selection(),
    targetSpeed(0.0),
    targetVelocity(0.0, 0.0, 0.0),
    initialVelocity(0.0, 0.0, 0.0),
    beginAccelTime(0.0),
    observerMode(Free),
    hudDetail(1)
{
}


Simulation::~Simulation()
{
    // TODO: Clean up!
}


static void displayDistance(Console& console, double distance)
{
    if (distance >= astro::AUtoLightYears(1000.0f))
        console.printf("%.3f ly", distance);
    else if (distance >= astro::kilometersToLightYears(10000000.0))
        console.printf("%.3f au", astro::lightYearsToAU(distance));
    else
        console.printf("%.3f km", astro::lightYearsToKilometers(distance));
}


static void displayStarInfo(Console& console,
                            Star& star,
                            StarNameDatabase& starNameDB,
                            double distance)
{
    // Print the star name and designations
    StarNameDatabase::iterator iter = starNameDB.find(star.getCatalogNumber());
    if (iter != starNameDB.end())
    {
        StarName* starName = iter->second;

        if (starName->getName() != "")
            console << starName->getName() << "  /  ";

        Constellation* constellation = starName->getConstellation();
        if (constellation != NULL)
            console << starName->getDesignation() << ' ' <<  constellation->getGenitive() << "  /  ";
    }
    if ((star.getCatalogNumber() & 0xf0000000) == 0)
        console << "HD " << star.getCatalogNumber() << '\n';
    else
        console << "HIP " << (star.getCatalogNumber() & 0x0fffffff) << '\n';
    
    console.printf("Abs (app) mag = %.2f (%.2f)\n",
                   star.getAbsoluteMagnitude(),
                   astro::absToAppMag(star.getAbsoluteMagnitude(), (float) distance));
    console << "Class: " << star.getStellarClass() << '\n';
    console.printf("Radius: %.2f Rsun\n", star.getRadius() / 696000.0f);
}


static void displayPlanetInfo(Console& console,
                              Body& body,
                              double distance)
{
    console << body.getName() << '\n';
    console << "Radius: " << body.getRadius() << " km\n";
    console << "Day length: " << body.getRotationPeriod() << " hours\n";
}


void Simulation::displaySelectionInfo(Console& console)
{
    if (selection.star != NULL)
    {
        Vec3d v = astro::universalPosition(Point3d(0, 0, 0), selection.star->getPosition()) - 
            observer.getPosition();
        console << "Distance to target: ";
        displayDistance(console, v.length());
        console << '\n';
        displayStarInfo(console, *selection.star, *starNameDB, v.length());
    }
    else if (selection.body != NULL)
    {
        uint32 starNumber = Star::InvalidStar;
        if (selection.body->getSystem() != NULL)
            starNumber = selection.body->getSystem()->getStarNumber();
        Star *star = stardb->find(starNumber);
        
        if (star != NULL)
        {
            Vec3d v = astro::universalPosition(selection.body->getHeliocentricPosition(simTime / 86400.0), star->getPosition()) - observer.getPosition();
            console << "Distance to target: ";
            displayDistance(console, v.length());
            console << '\n';
            displayPlanetInfo(console, *selection.body, v.length());
        }
    }
}


void  Simulation::render(Renderer& renderer)
{
    Console* console = renderer.getConsole();
    console->clear();
    console->home();

    if (hudDetail > 0)
    {
        console->printf("Visible stars = %d\n", visibleStars->getVisibleSet()->size());

        // Display the velocity
        {
            double v = observer.getVelocity().length();
            char* units;

            if (v < astro::AUtoLightYears(1000))
            {
                if (v < astro::kilometersToLightYears(10000000.0f))
                {
                    v = astro::lightYearsToKilometers(v);
                    units = "km/s";
                }
                else
                {
                    v = astro::lightYearsToAU(v);
                    units = "AU/s";
                }
            }
            else
            {
                units = "ly/s";
            }

            console->printf("Speed: %f %s\n", v, units);
        }

        // Display the date
        *console << astro::Date(simTime / 86400.0) << '\n';

        displaySelectionInfo(*console);
        
        *console << typedText;

    }

    renderer.render(observer,
                    *stardb,
                    *visibleStars,
                    closestSolarSystem,
                    simTime);
}


static Quatf lookAt(Point3f from, Point3f to, Vec3f up)
{
    Vec3f n = from - to;
    n.normalize();
    Vec3f v = up ^ n;
    v.normalize();
    Mat4f r = Mat4f::rotation(v, (float) PI / 2);
    Vec3f u = n * r;
    return ~Quatf(Mat3f(v, u, n));
}


SolarSystem* Simulation::getSolarSystem(Star* star)
{
    uint32 starNum = star->getCatalogNumber();
    
    SolarSystemCatalog::iterator iter = solarSystemCatalog->find(starNum);
    if (iter == solarSystemCatalog->end())
        return NULL;
    else
        return iter->second;
}


Star* Simulation::getSun(Body* body)
{
    PlanetarySystem* system = body->getSystem();
    if (system == NULL)
        return NULL;
    else
        return stardb->find(system->getStarNumber());
}


UniversalCoord Simulation::getSelectionPosition(Selection& sel, double when)
{
    if (sel.body != NULL)
    {
        Point3f sunPos(0.0f, 0.0f, 0.0f);
        Star* sun = getSun(sel.body);
        if (sun != NULL)
            sunPos = sun->getPosition();
        return astro::universalPosition(sel.body->getHeliocentricPosition(when / 86400.0),
                                        sunPos);
    }
    else if (sel.star != NULL)
    {
        return astro::universalPosition(Point3d(0.0, 0.0, 0.0), sel.star->getPosition());
    }
    else
    {
        return UniversalCoord(Point3d(0.0, 0.0, 0.0));
    }
}


void Simulation::setStarDatabase(StarDatabase* db,
                                 StarNameDatabase* namedb,
                                 SolarSystemCatalog* catalog)
{
    stardb = db;
    starNameDB = namedb;
    solarSystemCatalog = catalog;

    if (visibleStars != NULL)
    {
        delete visibleStars;
        visibleStars = NULL;
    }
    if (db != NULL)
    {
        visibleStars = new VisibleStarSet(stardb);
        visibleStars->setLimitingMagnitude(5.0f);
        visibleStars->setCloseDistance(10.0f);
        visibleStars->updateAll(observer);
    }
}


// Set the time in seconds from J2000
void Simulation::setTime(double t)
{
    simTime = t;
}


void Simulation::update(double dt)
{
    realTime += dt;
    simTime += dt * timeScale;

    if (observerMode == Travelling)
    {
        float t = clamp((realTime - journey.startTime) / journey.duration);

        // Smooth out the linear interpolation of position
        float u = (float) sin(sin(t * PI / 2) * PI / 2);
        Vec3d jv = journey.to - journey.from;
        UniversalCoord p = journey.from + jv * (double) u;

        // Interpolate the orientation using lookAt()
        // We gradually change the focus point for lookAt() from the initial 
        // focus to the destination star over the first half of the journey
        Vec3d lookDir0 = journey.initialFocus - journey.from;
        Vec3d lookDir1 = journey.finalFocus - journey.to;
        lookDir0.normalize();
        lookDir1.normalize();
        Vec3d lookDir;
        if (t < 0.5f)
        {
            // Smooth out the interpolation of the focus point to avoid
            // jarring changes in orientation
            double v = sin(t * PI);

            double c = lookDir0 * lookDir1;
            double angle = acos(c);
            if (c >= 1.0 || angle < 1.0e-6)
            {
                lookDir = lookDir0;
            }
            else
            {
                double s = sin(angle);
                double is = 1.0 / s;

                // Spherically interpolate the look direction between the
                // intial and final directions.
                lookDir = lookDir0 * (sin((1 - v) * angle) * is) +
                          lookDir1 * (sin(v * angle) * is);

                // Linear interpolation wasn't such a good idea . . .
                // lookDir = lookDir0 + (lookDir1 - lookDir0) * v;
            }
        }
        else
        {
            lookDir = lookDir1;
        }

        observer.setOrientation(lookAt(Point3f(0, 0, 0),
                                       Point3f((float) lookDir.x,
                                               (float) lookDir.y,
                                               (float) lookDir.z),
                                       journey.up));
        observer.setPosition(p);

        // If the journey's complete, reset to manual control
        if (t == 1.0f)
        {
            observer.setPosition(journey.to);
            observerMode = Free;
            observer.setVelocity(Vec3d(0, 0, 0));
            targetVelocity = Vec3d(0, 0, 0);
        }
    }
    else if (observerMode == Following)
    {
        Point3d posRelToSun = followInfo.body->getHeliocentricPosition(simTime / 86400.0) + followInfo.offset;
        observer.setPosition(astro::universalPosition(posRelToSun,
                                                      followInfo.sun->getPosition()));
    }
    else
    {
        if (observer.getVelocity() != targetVelocity)
        {
            double t = clamp((realTime - beginAccelTime) / VELOCITY_CHANGE_TIME);
            observer.setVelocity(observer.getVelocity() * (1.0 - t) +
                                 targetVelocity * t);
        }

        observer.update(dt);
    }

    if (visibleStars != NULL)
        visibleStars->update(observer, 0.05f);

    // Find the closest solar system
    Point3f observerPos = (Point3f) observer.getPosition();
    vector<uint32>* closeStars = visibleStars->getCloseSet();
    for (int i = 0; i < closeStars->size(); i++)
    {
        uint32 starIndex = (*closeStars)[i];
        Star* star = stardb->getStar(starIndex);
        if (observerPos.distanceTo(star->getPosition()) < 1.0f)
        {
            SolarSystem* solarSystem = getSolarSystem(star);
            if (solarSystem != NULL)
                closestSolarSystem = solarSystem;
        }
    }

}


struct PlanetPickInfo
{
    float cosClosestAngle;
    Body* closestBody;
    Vec3d direction;
    Point3d origin;
    double jd;
};

bool PlanetPickTraversal(Body* body, void* info)
{
    PlanetPickInfo* pickInfo = (PlanetPickInfo*) info;

    Point3d bpos = body->getHeliocentricPosition(pickInfo->jd);
    Vec3d bodyDir = bpos - pickInfo->origin;
    bodyDir.normalize();
    double cosAngle = bodyDir * pickInfo->direction;
    if (cosAngle > pickInfo->cosClosestAngle)
    {
        pickInfo->cosClosestAngle = cosAngle;
        pickInfo->closestBody = body;
    }

    return true;
}

bool Simulation::pickPlanet(Observer& observer,
                            Star& sun,
                            SolarSystem& solarSystem,
                            Vec3f pickRay)
{
    PlanetPickInfo pickInfo;

    // Transform the pick direction
    pickRay = pickRay * observer.getOrientation().toMatrix4();
    pickInfo.direction = Vec3d((double) pickRay.x,
                               (double) pickRay.y,
                               (double) pickRay.z);
    pickInfo.origin    = astro::heliocentricPosition(observer.getPosition(),
                                                     sun.getPosition());
    pickInfo.cosClosestAngle = -1.0f;
    pickInfo.closestBody = NULL;
    pickInfo.jd = simTime / 86400.0f;

#if 0
    for (int i = 0; i < solarSystem.getSystemSize(); i++)
    {
        Body* body = solarSystem.getBody(i);
        Point3d bpos = body->getOrbit()->positionAtTime(simTime / 86400.0);
        Vec3d bodyDir = bpos - observerPos;
        bodyDir.normalize();
        
        double cosAngle = bodyDir * Vec3d((double) pickRay.x,
                                          (double) pickRay.y,
                                          (double) pickRay.z);
        if (cosAngle > cosAngleClosest)
        {
            cosAngleClosest = cosAngle;
            closest = i;
        }
    }

    if (cosAngleClosest > cos(degToRad(0.5f)))
    {
        selection = Selection(solarSystem.getBody(closest));
        return true;
    }
    else
    {
        selection = Selection();
        return false;
    }
#endif
    
    solarSystem.getPlanets()->traverse(PlanetPickTraversal, (void*) &pickInfo);
    if (pickInfo.cosClosestAngle > cos(degToRad(0.5f)))
    {
        selection = Selection(pickInfo.closestBody);
        return true;
    }
    else
    {
        selection = Selection();
        return false;
    }

    return false;
}


void Simulation::pickStar(Vec3f pickRay)
{
    // Transform the pick direction
    pickRay = pickRay * observer.getOrientation().toMatrix4();

    Point3f observerPos = (Point3f) observer.getPosition();
    vector<uint32>* vis = visibleStars->getVisibleSet();
    int nStars = vis->size();


    float cosAngleClosest = -1.0f;
    int closest = -1;

    for (int i = 0; i < nStars; i++)
    {
        int starIndex = (*vis)[i];
        Star* star = stardb->getStar(starIndex);
        Vec3f starDir = star->getPosition() - observerPos;
        starDir.normalize();
        
        float cosAngle = starDir * pickRay;
        if (cosAngle > cosAngleClosest)
        {
            cosAngleClosest = cosAngle;
            closest = starIndex;
        }
    }

    if (cosAngleClosest > cos(degToRad(0.5f)))
    {
        selection = Selection(stardb->getStar(closest));
    }
    else
    {
        selection = Selection();
    }
}


void Simulation::pickObject(Vec3f pickRay)
{
    bool planetSelected = false;

    Point3f observerPos = (Point3f) observer.getPosition();
    vector<uint32>* closeStars = visibleStars->getCloseSet();
    for (int i = 0; i < closeStars->size(); i++)
    {
        uint32 starIndex = (*closeStars)[i];
        Star* star = stardb->getStar(starIndex);
        if (observerPos.distanceTo(star->getPosition()) < 1.0f)
        {
            SolarSystem* solarSystem = getSolarSystem(star);
            if (solarSystem != NULL)
            {
                planetSelected = pickPlanet(observer, *star, *solarSystem, pickRay);
            }
        }
    }

    if (!planetSelected)
        pickStar(pickRay);
}


void Simulation::computeJourneyParameters(Selection& destination, JourneyParams& jparams)
{
    UniversalCoord targetPosition = getSelectionPosition(selection, simTime);

    Vec3d v = targetPosition - observer.getPosition();
    double distanceToTarget = v.length();
    double maxOrbitDistance = (selection.body != NULL) ? astro::kilometersToLightYears(5.0f * selection.body->getRadius()) : 0.5f;
    double orbitDistance = (distanceToTarget > maxOrbitDistance * 10.0f) ? maxOrbitDistance : distanceToTarget * 0.1f;


    v.normalize();

    // TODO: This should be an option someplace
    jparams.duration = 5.0f;

    jparams.startTime = realTime;

    // Right where we are now . . .
    jparams.from = observer.getPosition();

    // The destination position lies along the line between the current
    // position and the star
    jparams.to = targetPosition - v * orbitDistance;
    jparams.initialFocus = jparams.from +
        (Vec3f(0, 0, -1.0f) * observer.getOrientation().toMatrix4());
    jparams.finalFocus = targetPosition;
    jparams.up = Vec3f(0, 1, 0) * observer.getOrientation().toMatrix4();
}


void Simulation::applyForce(Vec3f force, float dt)
{
    Vec3d f(force.x * dt, force.y * dt, force.z * dt);
    observer.setVelocity(observer.getVelocity() + f);
}

void Simulation::applyForceRelativeToOrientation(Vec3f force, float dt)
{
    applyForce(force * observer.getOrientation().toMatrix4(), dt);
}

Quatf Simulation::getOrientation()
{
    return observer.getOrientation();
}

void Simulation::setOrientation(Quatf q)
{
    observer.setOrientation(q);
}

// Orbit around the selection (if there is one.)  This involves changing
// both the observer's position and orientation.
void Simulation::orbit(Quatf q)
{
    if (selection.body != NULL || selection.star != NULL)
    {
        UniversalCoord focusPosition = getSelectionPosition(selection, simTime);
        Vec3d v = observer.getPosition() - focusPosition;
        double distance = v.length();

        Mat3f m = conjugate(observer.getOrientation()).toMatrix3();


        // Convert the matrix to double precision so we can multiply it
        // by the double precision vector.  Yuck.  VC doesn't seem to
        // be able to figure out that the constructor declared in
        // vecmath.h should allow: md = m
        Mat3d md;
        md[0][0] = m[0][0]; md[0][1] = m[0][1]; md[0][2] = m[0][2];
        md[1][0] = m[1][0]; md[1][1] = m[1][1]; md[1][2] = m[1][2];
        md[2][0] = m[2][0]; md[2][1] = m[2][1]; md[2][2] = m[2][2];
        v = v * md;

        observer.setOrientation(observer.getOrientation() * q);
        
        m = observer.getOrientation().toMatrix3();
        md[0][0] = m[0][0]; md[0][1] = m[0][1]; md[0][2] = m[0][2];
        md[1][0] = m[1][0]; md[1][1] = m[1][1]; md[1][2] = m[1][2];
        md[2][0] = m[2][0]; md[2][1] = m[2][1]; md[2][2] = m[2][2];
        v = v * md;

        // Roundoff errors will accumulate and cause the distance between
        // viewer and focus to change unless we take steps to keep the
        // length of v constant.
        v.normalize();
        v *= distance;

        observer.setPosition(focusPosition + v);
    }
}

void Simulation::setTargetSpeed(float s)
{
    targetSpeed = s;
    Vec3f v = Vec3f(0, 0, -s) * observer.getOrientation().toMatrix4();
    targetVelocity = Vec3d(v.x, v.y, v.z);
    initialVelocity = observer.getVelocity();
    beginAccelTime = realTime;
}

float Simulation::getTargetSpeed()
{
    return targetSpeed;
}

void Simulation::gotoStar()
{
    if (selection.body != NULL || selection.star != NULL)
    {
        computeJourneyParameters(selection, journey);
        observerMode = Travelling;
    }
}

void Simulation::follow()
{
    if (observerMode == Following)
    {
        observerMode = Free;
    }
    else
    {
        if (selection.body != NULL)
        {
            Star* sun = getSun(selection.body);
            if (sun != NULL)
            {
                observerMode = Following;
                followInfo.sun = sun;
                followInfo.body = selection.body;
                Point3d planetPos = selection.body->getHeliocentricPosition(simTime / 86400.0);
                Point3d observerPos = astro::heliocentricPosition(observer.getPosition(),
                                                                  sun->getPosition());
                followInfo.offset = observerPos - planetPos;
            }
        }
    }
}


void Simulation::selectStar(uint32 catalogNo)
{
    selection = Selection(stardb->find(catalogNo));
}


void Simulation::selectPlanet(int index)
{
    if (index < 0)
    {
        if (selection.body != NULL)
        {
            PlanetarySystem* system = selection.body->getSystem();
            if (system != NULL)
                selectStar(system->getStarNumber());
        }
    }
    else
    {
        Star* star = NULL;
        if (selection.star != NULL)
        {
            star = selection.star;
        }
        else if (selection.body != NULL)
        {
            star = getSun(selection.body);
        }

        SolarSystem* solarSystem = NULL;
        if (star != NULL)
            solarSystem = getSolarSystem(star);
        else
            solarSystem = closestSolarSystem;

        if (solarSystem != NULL && index < solarSystem->getPlanets()->getSystemSize())
            selection = Selection(solarSystem->getPlanets()->getBody(index));
    }
}


void Simulation::selectBody(string s)
{
    uint32 catalogNum;
    if (GetCatalogNumber(s, *starNameDB, catalogNum))
    {
        selectStar(catalogNum);
    }
    else if (closestSolarSystem != NULL)
    {
        Body* body = closestSolarSystem->getPlanets()->find(s, true);
        if (body != NULL)
            selection = Selection(body);
    }
}


void Simulation::typeChar(char c)
{
    if (c == '\n')
    {
        selectBody(typedText);
        typedText = "";
    }
    else
    {
        typedText += c;
    }
}


double Simulation::getTimeScale()
{
    return timeScale;
}

void Simulation::setTimeScale(double _timeScale)
{
    timeScale = _timeScale;
}


int Simulation::getHUDDetail() const
{
    return hudDetail;
}

void Simulation::setHUDDetail(int detail)
{
    hudDetail = detail;
}


SolarSystem* Simulation::getNearestSolarSystem() const
{
    return closestSolarSystem;
}
